//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.androidnative.gcm;

import android.graphics.Bitmap;

public interface PictureLoadingTaskListener {
	void onPictureLoaded(Bitmap var1);
}
